DECLARE @cols AS NVARCHAR(MAX);
DECLARE @createTable AS NVARCHAR(MAX);
DECLARE @query AS NVARCHAR(MAX);

-- Get the column names
SELECT @cols = STRING_AGG(QUOTENAME(name), ',') 
FROM sys.columns 
WHERE object_id = OBJECT_ID('[apportionment-dataset]');

-- Construct the column definition for the new table
SELECT @createTable = STRING_AGG(
    QUOTENAME(name) + ' ' + system_type_name, ', ')
FROM (
    SELECT name, system_type_name
    FROM sys.dm_exec_describe_first_result_set(N'SELECT * FROM [apportionment-dataset]', NULL, 0)
) AS column_definitions;

-- Create the new table with the same structure as the original table
SET @createTable = 'CREATE TABLE [cleaned_apportionment-dataset] (' + @createTable + ')';
EXEC sp_executesql @createTable;

-- Construct the query to replace NULL values with 0
SELECT @cols = STRING_AGG(
    'ISNULL(' + QUOTENAME(name) + ', 0) AS ' + QUOTENAME(name), ', ') 
FROM sys.columns 
WHERE object_id = OBJECT_ID('[apportionment-dataset]');

-- Insert the cleaned data into the new table
SET @query = 'INSERT INTO [cleaned_apportionment-dataset] SELECT ' + @cols + ' FROM [apportionment-dataset]';

-- Execute the constructed query
EXEC sp_executesql @query;
select * from [cleaned_apportionment-dataset]