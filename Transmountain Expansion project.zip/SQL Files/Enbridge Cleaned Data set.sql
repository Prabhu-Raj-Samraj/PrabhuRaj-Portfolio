drop table [enbridge-mainline-throughput-and-capacity-dataset-cleaned]
CREATE TABLE [enbridge-mainline-throughput-and-capacity-dataset-cleaned] (
    [Month] INT,
    [Year] INT,
    [Corporate_Entity] NVARCHAR(255),
    [Pipeline_Name] NVARCHAR(255),
    [Key_Point] NVARCHAR(255),
    [Latitude] FLOAT,
    [Longitude] FLOAT,
    [Direction_of_Flow] NVARCHAR(255),
    [Trade_Type] NVARCHAR(255),
    [Product] NVARCHAR(255),
    [Throughput_1000_m3_d] FLOAT,
    [Nameplate_Capacity_1000_m3_d] FLOAT,
    [Available_Capacity_1000_m3_d] FLOAT,
    [Reason_For_Variance] NVARCHAR(255)
);

-- Step 2: Define variables for dynamic SQL
DECLARE @cols NVARCHAR(MAX);
DECLARE @query NVARCHAR(MAX);

-- Step 3: Construct the COALESCE expression for each column with appropriate default values
SELECT @cols = STRING_AGG(
    CASE
		WHEN name IN ('Throughput_1000_m3_d', 'Nameplate_Capacity_1000_m3_d', 'Available_Capacity_1000_m3_d')
            THEN 'ROUND(COALESCE(CAST([' + name + '] AS FLOAT), 0), 2) AS [' + name + ']'
        WHEN system_type_id IN (56, 60, 62, 106, 108, 122, 127, 104, 48, 52, 59, 55, 61, 58) -- Numeric types
            THEN 'COALESCE(CAST([' + name + '] AS FLOAT), 0) AS [' + name + ']'
        ELSE -- NVARCHAR and other types
            'COALESCE([' + name + '], '''') AS [' + name + ']'
    END, ', ')
FROM sys.columns
WHERE object_id = OBJECT_ID('[enbridge-mainline-throughput-and-capacity-dataset]');

-- Step 4: Construct the dynamic SQL query
SET @query = '
INSERT INTO [enbridge-mainline-throughput-and-capacity-dataset-cleaned]
SELECT ' + @cols + '
FROM [enbridge-mainline-throughput-and-capacity-dataset];';

-- Step 5: Execute the dynamic SQL query
EXEC sp_executesql @query;
select * from [enbridge-mainline-throughput-and-capacity-dataset-cleaned]