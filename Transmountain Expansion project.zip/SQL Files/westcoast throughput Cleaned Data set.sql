CREATE TABLE [westcoast-throughput-and-capacity-dataset-cleaned] (
    [Corporate Entity] NVARCHAR(255),
    [Pipeline Name] NVARCHAR(255),
    [Key Point] NVARCHAR(255),
    [Latitude] FLOAT,
    [Longitude] FLOAT,
    [Direction of Flow] NVARCHAR(255),
    [Trade Type] NVARCHAR(255),
    [Capacity (1000 m3/d)] FLOAT,
    [Throughput (1000 m3/d)] FLOAT,
    [Throughput (GJ/d)] FLOAT,
    [Date] DATE
);
INSERT INTO [westcoast-throughput-and-capacity-dataset-cleaned]
SELECT
    [Corporate_Entity],
    [Pipeline_Name],
    [Key_Point],
    [Latitude],
    [Longitude],
    [Direction_of_Flow],
    [Trade_Type],
    [Capacity_1000_m3_d],
    ROUND([Throughput_1000_m3_d], 2) AS [Throughput (1000 m3/d)],
    ROUND([Throughput_GJ_d], 2) AS [Throughput (GJ/d)],
    CAST(CONCAT([Year], '-', [Month], '-', [Date]) AS DATE) AS [Date]
FROM 
    [westcoast-throughput-and-capacity-dataset];
select * from [westcoast-throughput-and-capacity-dataset-cleaned]