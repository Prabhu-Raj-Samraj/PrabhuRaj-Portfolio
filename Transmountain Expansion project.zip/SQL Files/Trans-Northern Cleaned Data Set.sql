CREATE TABLE [trans-northern-throughput-and-capacity-dataset-cleaned] (
    [Corporate Entity] NVARCHAR(255),
    [Pipeline Name] NVARCHAR(255),
    [Key Point] NVARCHAR(255),
    [Latitude] FLOAT,
    [Longitude] FLOAT,
    [Direction of Flow] NVARCHAR(255),
    [Trade Type] NVARCHAR(255),
    [Product] NVARCHAR(255),
    [Nameplate_Capacity_1000_m3_d] FLOAT,
    [Available_Capacity_1000_m3_d] FLOAT,
    [Throughput (1000 m3/d)] FLOAT,
    [Day] INT,
    [Date] DATE
);

-- Step 2: Insert the cleaned data into the new table
INSERT INTO [trans-northern-throughput-and-capacity-dataset-cleaned]
SELECT 
    COALESCE([Corporate_Entity], '0') AS [Corporate Entity],
    COALESCE([Pipeline_Name], '0') AS [Pipeline Name],
    COALESCE([Key_Point], '0') AS [Key Point],
    COALESCE([Latitude], 0) AS [Latitude],
    COALESCE([Longitude], 0) AS [Longitude],
    COALESCE([Direction_of_Flow], '0') AS [Direction of Flow],
    COALESCE([Trade_Type], '0') AS [Trade Type],
    COALESCE([Product], '0') AS [Product],
    COALESCE([Nameplate_Capacity_1000_m3_d], 0) AS [Nameplate_Capacity_1000_m3_d],
    COALESCE(ROUND([Available_Capacity_1000_m3_d], 2), 0) AS [Available_Capacity_1000_m3_d],
    COALESCE(ROUND([Throughput_1000_m3_d], 2), 0) AS [Throughput (1000 m3/d)],
    1 AS [Day], -- Adding a default value for Day as 1
    CAST(CONCAT(COALESCE([Year], '0'), '-', COALESCE([Month], '0'), '-', '01') AS DATE) AS [Date]
FROM 
    [trans-northern-throughput-and-capacity-dataset];
select * from [trans-northern-throughput-and-capacity-dataset-cleaned]